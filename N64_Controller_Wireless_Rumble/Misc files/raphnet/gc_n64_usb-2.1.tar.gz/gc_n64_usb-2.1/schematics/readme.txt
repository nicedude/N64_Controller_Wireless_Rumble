For the latest schematics, please visit:
http://www.raphnet.net/electronique/gc_n64_usb/index_en.php


