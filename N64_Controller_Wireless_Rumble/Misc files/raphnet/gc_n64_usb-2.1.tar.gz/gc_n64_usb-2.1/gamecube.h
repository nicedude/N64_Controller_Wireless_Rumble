#include "gamepad.h"

Gamepad *gamecubeGetGamepad(void);

